# Assets

Custom SVG artwork for the profile README. All files are standalone (no scripts, no external images).

| Prefix | Purpose |
| --- | --- |
| `banner`, `status`, `terminal`, `footer` | Hero and closing graphics |
| `section-*` | Section dividers |
| `card-*` | Project cards (one per featured repository) |
| `stack` | Technology panel (hands-on vs. learning) |
| `btn-*` | Contact buttons |
