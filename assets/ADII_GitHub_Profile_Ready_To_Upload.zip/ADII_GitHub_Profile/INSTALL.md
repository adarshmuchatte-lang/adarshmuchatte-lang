# ADII GitHub Profile — Install Guide

This bundle contains a GitHub-compatible profile README and one integrated animated hero GIF. The banner includes the title, galaxy effects, and all eight technology labels inside the same GIF, so they animate as one composition. The README uses relative path `./assets/hero.gif`.

## Update your profile repository

1. Open https://github.com/adarshmuchatte-lang/adarshmuchatte-lang
2. Download or extract this ZIP on your computer.
3. In your profile repository, replace `README.md` with the included `README.md`.
4. Open the repository's `assets` folder. Upload the included `assets/hero.gif` into that folder, creating `assets` if needed. Keep the path exactly `assets/hero.gif`.
5. Commit the changes to the `main` branch.
6. Visit https://github.com/adarshmuchatte-lang and refresh your profile.

## Upload via GitHub website

- To replace `README.md`: open the file, click the pencil/edit button, replace the contents with the included file, then commit.
- To upload `hero.gif`: open the `assets` directory, choose **Add file → Upload files**, select `hero.gif`, and commit.

## Notes

- The hero banner is a GIF file; do not turn it into separate images if you want the title, effects, and technology labels to remain synchronized.
- The skill icons, stats, streak, and activity graph use external services. Those sections may fail temporarily if a service is down.
- No CSS or JavaScript is required inside the GitHub README.
